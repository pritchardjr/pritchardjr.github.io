/* driver.cc
 *
 * program for mimicing the results of BL04
 * Call by 
 *   driver.x -z6 > (output filename)
 *
 */

#include <iostream>
#include <fstream>
#include "math.h"
#include "atomic.h"
#include "nrutil.h"

using namespace std;

/******************************************************************/


int main(int argc, char *argv[])
{
 

  double z(5.0),zp(7.0),zin(2);
  int i,j,jmax(1);
  double n;
  int rNMAX(10);
  double **pastore1;
  double **pastore2;
  
  // Handle arguments 
  while ((argc>1) && (argv[1][0]=='-')) {
    switch (argv[1][1]) {
    case 'z':
      zin=atof(&argv[1][2]);
      break;
    default:
      cerr << "Bad option" <<argv[1] <<"\n";
    }
    --argc;
    ++argv;
  }

  // Initialise Atomics class
  pastore1=dmatrix(1,rNMAX,1,2*(rNMAX-1)+1);
  pastore2=dmatrix(1,rNMAX,1,2*(rNMAX-1)+1);

  Atomics a(rNMAX,pastore1,pastore2);


  /****************************************************************
   ************  Output recycling fractions ***********************
  ****************************************************************
  int nl,ll,jl;
  ofstream fout;
  char *file="recycle_data.dat";

  fout.open(file);

  for(nl=1;nl<=rNMAX;nl++){
    for(ll=0;ll<nl;ll++){
      for(jl=0;jl<2;jl++){
	if(ll==0) jl=1;
 	cout <<  nl<<"\t"<<ll<<"\t"<<double(ll)-0.5+double(jl)<<"\n";     
	fout <<  nl<<"\t"<<ll<<"\t"<<double(ll)-0.5+double(jl)<<"\t";
	fout << a.getRecycleLyman(double(nl),double(ll),double(ll)-0.5+double(jl),pastore1)<<"\t" ;
	fout << a.getRecycleLymanThick(double(nl),double(ll),double(ll)-0.5+double(jl),pastore2) << endl;
      }
    }
  }
  fout.close();

  *****************************************************************/

  /****************************************************************
   ************  Output recycling fractions only for P states   ***
   ****************************************************************/
  int nl,ll,jl;
  ofstream fout;
  char *file="lyman_recycle_data.dat";

  fout.open(file);

  for(nl=1;nl<=rNMAX;nl++){
    ll=1;
    jl=1;
    cout <<  nl<<"\t"<<ll<<"\t"<<double(ll)-0.5+double(jl)<<"\n";     
    fout <<  nl<<"\t"<<ll<<"\t"<<double(ll)-0.5+double(jl)<<"\t";
    fout << a.getRecycleLyman(double(nl),double(ll),double(ll)-0.5+double(jl),pastore1)<<"\t" ;
    fout << a.getRecycleLymanThick(double(nl),double(ll),double(ll)-0.5+double(jl),pastore2) << endl;  
  }
  fout.close();

  /*****************************************************************/

  /****************************************************************
   **  Output lyman transition probabilities  only for P states   ***
   ****************************************************************
  int nl,ll,jl;
  ofstream fout;
  char *file="lyman_transition_prob.dat";

  fout.open(file);

  for(nl=2;nl<=rNMAX;nl++){
    ll=1;
    jl=1;
    cout <<  nl<<"\t"<<ll<<"\t"<<double(ll)-0.5+double(jl)<<"\n";     
    fout <<  nl<<"\t"<<ll<<"\t"<<double(ll)-0.5+double(jl)<<"\t";
    fout << a.transitionP(double(nl),double(ll),double(ll)-0.5+double(jl),1.0,0.0,0.5)<<endl ;

  }
  fout.close();

  *****************************************************************/

  /****************************************************************
   **  Output Table for paper   ***
  ****************************************************************
  int nl,ll,jl;
  ofstream fout;
  char *file="paper_table.dat";
  int nn;

  fout.open(file);
  fout.precision(5);

  for(nl=1;nl<=10;nl++){
    ll=1;
    jl=1;
    cout <<  nl<<"\t"<<ll<<"\t"<<double(ll)-0.5+double(jl)<<"\n";
    nn=nl;
    fout <<  nn<<" & ";
    fout << a.getRecycleLymanThick(double(nn),double(ll),double(ll)-0.5+double(jl),pastore2) << " & ";
    fout << a.transitionP(double(nn),double(ll),double(ll)-0.5+double(jl),1.0,0.0,0.5)<<" & ";
   nn=nl+10;
    fout <<  nn<<" & ";
    fout << a.getRecycleLymanThick(double(nn),double(ll),double(ll)-0.5+double(jl),pastore2) << " & ";
    fout << a.transitionP(double(nn),double(ll),double(ll)-0.5+double(jl),1.0,0.0,0.5)<<" & ";
   nn=nl+20;
    fout <<  nn<<" & ";
    fout << a.getRecycleLymanThick(double(nn),double(ll),double(ll)-0.5+double(jl),pastore2) << " & ";
    fout << a.transitionP(double(nn),double(ll),double(ll)-0.5+double(jl),1.0,0.0,0.5)<<"\\\\"<<endl;

  }
  fout.close();

  *****************************************************************/

  free_dmatrix(pastore1,1,rNMAX,1,2*(rNMAX-1)+1);
  free_dmatrix(pastore2,1,rNMAX,1,2*(rNMAX-1)+1);

  return 0;
}




